"""
    Module net.fpmp of package pyloa:
    Methods for solving the "fair p-median problem"
"""
import numpy as np
import matplotlib.pyplot as plt
from math import floor, ceil
from pyloa.net.pmedian import PMedian

#--------------------------------------------------------------------------

class FPMP( PMedian ):
    """
    Class implementing methods for solving the "fair p-median problem".
    The "fair p-median problem" is actually a bi-objective facility location
    problem. Its objective function is the weighted sum of the total distance
    the user's have to take to the nearest open facility and a measure of
    inequity in these distances. The applied inequity measure is the so-called 
    conditional β-mean defined as the average distance the 100*β% demand units 
    travelling the longest distance have to travel. For a given allocation x(i,j) 
    of the w(i) customers at location i to facilities j with distance c(i,j), 
    the conditional β-mean Mβ(x) is obtained by solving
     
    .. math::
    
        M_\\beta(x) = 1/(k_\\beta) & \\max  \\sum_i\\sum_j C_i(x) z_i \\\\
                    \\text{s.t.: } & \\sum_i z_i = k_\\beta  \\\\
                                   & 0 \\le z_i \\le w_i \\quad\\forall\\,i,
    where
    
    ..math::
    
        C_i(x) = \sum_{j\in J} c_{ij} x_{ij},\;k_\beta = \lceil W \rceil \\text{ and }W=\\sum_i w_i
    
    Alternatively, we may take the dual of the above program with dual the 
    variables :math:`u` and :math:`v_{ji}` and obtain
    
    .. math::
    
        M_\\beta(x) =  \\min & u + \\frac{1}{k_\\beta}\\sum_i w_i v_i  \\\\
             \\text{s.t.: }  & u + v_i \le C_i(x)\, \\quad\\forall\\,i\\,,\\\\
                             & v_i \ge 0 \\quad\\forall\\,i\\,.
                       
    Observe that :math:`v_i = \\max\\{0, C_i(x)/ - u\\}` in any optimal 
    solution. The above dual program thus reduces to 
    
    .. math::
    
        M_\\beta(x) = \\min_u \\Bigl \\{u + \\frac{1}{k_\\beta}\\sum_i w_i \\max\\{0,C_i(x)-u \\}\\Bigr\\}
    
    For given weights :math:`\\lambda` and :math:`1-\\lambda` for the inequity 
    and total distance objective, resp., the fair p-median problem is then 
    to minimize the (convex) function
    
    .. math::
    
        \\Phi(u) = \lambda u + \\min \\sum_i\\sum_j w_i c_{ij}(u)x_{ij}
    
    over the possible optimal values of the dual variable u. The above
    minimum is thereby taken over the feasible solutions to the p-median problem.. 
    The distances above are parametrized by the dual variable u and equal
    
    .. math::
    
        c_{ij}(u) = (1-\\lambda)/W u c_{ij} + (\\lambda/k_\\beta)\\max\\{0, c_{ij}-u \\}
    
    
    Minimizing :math:`\Phi(u)` over u is the time being done via Golden Section Search. 
    The set of possible optimal u-values is :math:`U=\\{c_{ij}\\forall\\,i,j\\}`. Note 
    that the optimal u is decreasing with increasing value of β. Hence, if an optimal 
    u=u' is known for given β=β', we could limit the search for optimal u and
    given :math:`\\beta \\le \\beta'` to values of u not smaller than u', whereas an 
    optimal u for a :math:`\\beta \\ge \\beta'` is no larger than u'.
    
    """
    def __init__( self, fname=None, orlib=False, d=None, m=0, n=0, w=None, p=None ):
        """
        Creates an instance of the fair p-median problem. The parameter β for 
        the conditional β-mean has default value of 0.1 but can be changed using 
        the property "beta". The objective weights are both equal to 1 (that is
        actuall 1/2 for inequity as well distance objective). The two objective 
        weights can be adjusted using the property "obj_weight", where obj_weight
        is a tuple of two positive floats, the first one is the inequity and
        the second the distance's weight.
        
        For all other parameters, see the base class 'PMedian' in the module 
        pyloa.net.pmedian
        """
        super().__init__(fname=fname, dstmat='matrix', orlib=orlib, d=d, m=m, n=n, w=w, p=p)
        
        self.set_default_options()
        
        self.__gratio = (np.sqrt(5)-1)/2.0
        """Golden section ratio"""
        
        self.__beta = 0.1 
        """Parameter beta in the conditional beta-mean"""
        
        self.__totW = self._w.sum()
        """Total demand"""
        
        self.__obj_weight = (1,1)
        """Weights for the objectives "inequity" and "total distanceinequity".
           The weight for the fixed cost is asssumed to be normed to 1."""
        
        self.__search_time = None 
        """Maximal time (sec) allowed for the solution search. If None, no limit is set."""
        
        self.__nodeLim = None 
        """Limit on the number of branch-and-tree nodes"""
        
        self.__D = None
        """Will keep a copy of the original distance matrix."""
           
        self.__U = None 
        """Numpy array of possible optimal u-values"""
        
        self.__umin = 0.0
        """Value of dual variable u where best solution found"""
        
        self.__kbeta = ceil( self.__totW*self.beta ) 
        """beta% of all single customers"""
        
        self.Phi = None 
        """Dictionary of funtion values Phi(u)"""
        
        self.__PhiMin = 0.0
        """Objective value of a solution to the fair p-median problem"""
        
        self.__beta_mean = 0.0 
        """Value of the conditional beta-mean in an (optimal) solution"""
        
        self.__solver = 'cplex'
        """Solver used to solve the p-median instances"""
         
    #---------------------------------------------
    # Class properties
    #---------------------------------------------
    @property 
    def beta(self):
        """
        Parameter beta in the conditional beta-mean.
        Inequity is measured as the average distance
        the 100*beta % demand units travelling 
        the longest distance have to travel.
        """
        return self.__beta
    
    @beta.setter 
    def beta(self, value : float ):
        """
        Set the beta value, a positive number strictly
        smaller than 1.
        """
        if value > 0 and value < 1: 
            self.__beta = value
            self.__kbeta = ceil(value*self.__totW)
    
    @property
    def obj_weight(self):
        """
        Tuple of positive objective weights, where the firs one
        is the inequity's weight and the second the weight 
        for the distance objective.
        """
        return self.__obj_weight

    @obj_weight.setter
    def obj_weight( self, value : tuple ): 
        self.__obj_weight = value

    @property
    def search_time(self):
        """
        Maximal time in seconds to search for an optimal solution.
        """
        return self.__search_time

    @search_time.setter
    def search_time( self, value : float or None ): 
        self.__search_time = value if isinstance(value,float) else None
        
    @property
    def nodeLim(self):
        """Limit on the number of nodes in the solver's branch-and-cut tree"""
        return self.__nodeLim
    
    @nodeLim.setter 
    def nodeLim(self, value : None or int ):
        self.__nodeLim = max(1,value) if isinstance(value,int) else None
        
    @property 
    def screen_output(self):
        return self.__screen_output 
    
    @screen_output.setter
    def screen_output(self, value : bool):
        self.__screen_output = value     
        
    @property 
    def umin(self):
        """Value of dual variable u at which best solution was found"""
        return self.__umin
    
    @property
    def PhiMin(self):
        """Objective value of best solution found to the fair CFLP"""
        return self.__PhiMin 
    
    @property 
    def beta_mean(self):
        """Return the conditional beta-mean for the obtained solution"""
        return( self.__beta_mean )
                
    @property 
    def inequity_cost(self):
        """Return the inequity cost (beta-mean times its weight)"""
        return( self.__beta_mean * self.__obj_weight[0] )   
    
    @property 
    def distance_cost(self):
        """Return the cost for the average weighted distance in a solution"""
        return( self.__obj_weight[1] * self.wdist / self.__totW )
        
    @property
    def solver(self):
        """Solver used for the p-median problem"""
        return self.__solver 
    
    @solver.setter 
    def solver(self, value : str ):
        """Set the p-median problem solver to the given value"""
        self.__solver = value   
    
    #---------------------------------------------
    
    def get_beta_mean( self, facilities=None, assigned=None, X=None ):
        """
        Computes the conditional beta-mean of a solution.
        
        Parameters
        ----------
        facilities : list or numpy array of int or None
            If not None, the list or array of open facility indices.
        assigned : list or numpy array of int or None 
            If not None, assigned[i] is the index of the closest open
            facility to customer index i.
        X : dict or None 
            If not None, then X should give the non-zero solution values
            of the allocation variables x(i,j). Keys of the dictionary are
            the (i,j) pairs, where i is the customer and j the facility 
            index such that x(i,j) > 0 in the solution. Note that if X
            is not None, then arguments facilities and assigned, if
            given, are ignored and just the cond.beta mean and u-value
            of the solution specified by X is returned.
            
        Returns
        -------
          mbeta : float 
              The conditional beta-mean of the solution specified
              by the assignment of customer points to facilities
              or, if assigned=None, by the set 'facilities' of
              open facilities.
          u : float 
              The beta-quantile of the distance distribution 
              in this solution, that is the value of the dual 
              variable u in the primal linear program for computing
              the conditional beta-mean.
              
        Example
        -------
        get_beta_mean( open_facilities ) returns the conditional beta-mean
        and corresponding u-value for the given set of open_facilities.
        
        get_beta_mean( assigned=the_assignment ) returns the conditional beta-mean
        and corresponding u-value for the given assignment of customer points
        to open facilities. The same is returned when using 
               get_beta_mean( open_facilities, assigned=the_assignment )
               
        get_beta_mean( X=Xvalues ) gives the conditional beta-mean and u-value
        of the solution specified by the dictionary Xvalues.
        """
        if X is None and facilities is None and assigned is None: return None, None 
        
        # Compute user distances to facilities in the given solution
        if not X is None:
            dists = np.zeros(self._m, dtype=float) 
            for i,j in X.keys(): dists[i] += self._dmat[i,j]*X[i,j] 
        elif assigned is None: 
            dists = self.min_wdist( facilities )
        else:
            dists = np.fromiter((self._dmat[i,assigned[i]] for i in range(self._m)),dtype=float)
        
        # Sum up the k_beta largest distances
        if np.any( self._w != 1 ):
            custs = np.flip( dists.argsort() )
            dsum, wsum = 0.0, 0.0
            for i in custs: 
                u = dists[i]
                if wsum + self._w[i] > self.__kbeta:
                    dsum += dists[i]*(self.__kbeta - wsum)
                    break
                dsum += dists[i]
                wsum += self._w[i]
        else: 
            dists.sort()
            dists = np.flip( dists )
            u = dists[self.__kbeta]
            dsum = dists[:self.__kbeta].sum()
        
        return dsum/self.__kbeta, u
        
    
    #---------------------------------------------
    
    def set_default_options(self):
        """
        Set all options (back) to default values
        """
        self.solver = 'cplex'
        self.__nodeLim = None  
        self.__search_time = None 
        self.__screen_output = True
        
    #---------------------------------------------
    
    def __adjust_dist( self, u ):
        """
        Adjust the distances of the p-median problem 
        to account for the inequity measure. Parameter 
        u is the current guess for the optimal dual variable u.
        """
        d_add = np.maximum( self.__D - u, 0.0)
        self._dmat = self.__obj_weight[1]*self.__D/self.__totW + self.__obj_weight[0]*d_add/self.__kbeta
        M = self.model   
        if not M is None:
            # Overwrite coefficients of variables x(i,j) in objective function
            cij = lambda ij : self._w[ij[0]]*self._dmat[ij[0],ij[1]]
            x = self.x
            M.minimize( M.dotf( x, cij ) ) 
         
    #---------------------------------------------
    
    def __comp_Phi ( self, u, save_facilities = True, track_time=True ):
        """
        Determine the value of the function 
        
            Phi(u) = \\lambda u + \min \sum_{ij} w_i c_{ij}(u)*x_{ij},
        
        Parameters
        ----------
        u : float
            value of the parameter u
        save_facilities : bool
            If True, the list of open facilities is remembered 
            in the class field self.facilities.        
        """
        if not self.model is None:
            self.__adjust_dist( u )
            self.cpxSolve( save_facilities=save_facilities, save_assignment=False)
            # Accumulate computational performance figures
            if track_time:
                self.pyCPU   += self.ctime[0]
                self.pyWall  += self.ctime[1]
                self.cpxWall += self.cpx_time 
                self.cpxTick += self.cpx_ticks 
                self.cpxNodes+= self.nodes_processed
            phi_u = self.wdist 
            Phi_u = phi_u + self.__obj_weight[0]*u
            return phi_u, Phi_u
                   
    #---------------------------------------------
    
    def get_full_func( self ):
        """
        Compute and return all function values Phi(u) for
        all possible optimal values of u. The result
        is stored in the dictionary self.F.
        """
        if self.__screen_output:
            print('='*32)
            print('Computing full function Phi(u)')
            print('-'*32)
            print('Iter',f"{'Current u':>11s}",f"{'Phi(u)':>14s}")
            print('-'*32)
            
        # Build the docplex model of the p-median problem
        self.silent = True
        self.cpxModel(x_continuous=True, weakModel=False)
        
        # Restrict number of nodes to be enumerated if limit is set
        if not self.__nodeLim is None:
            M = self.model
            M.parameters.mip.limits.nodes.set( self.__nodeLim )
        
        # Keep copy of distance matrix as later the distance matrix
        # is overwritten with a term involving the original matrix.    
        self.__D = self._dmat.copy()
        
        # Keep dictionary of Phi function values
        Phi = list()
        PhiMin = float('inf')
        
        # Get the list of different distances sorted in increasing manner
        if self.__U is None: self.__U = np.unique( self._dmat )  
        
        # Compute all function values and remember the minimum
        prev_phi_u = 0.0
        for itr, u in enumerate(self.__U):
            phi_u, Phi_u = self.__comp_Phi( u, save_facilities=False, track_time=False )
            Phi.append( Phi_u )
            if self.__screen_output: print(f"{itr:>4d}",f"{u:>11.7f}",f"{Phi_u:>14.2f}")
            if Phi_u < PhiMin: PhiMin, umin = Phi_u, u
            if abs( phi_u - prev_phi_u ) < 1.0E-05:
                # phi(u) is monotonically decreasing and thus reached constant value
                # Remaining function is Phi(u) = λ u + phi(u), phi(u)=constant
                break
        if itr < len( self.__U )-1:
            Phi_u.extend( [ phi_u + self.__obj_weight[0]*u for u in self.__U[itr+1:]] )
                      
        # Print minimum and minimizer
        if self.__screen_output: 
            print('-'*32)
            print('Minimum at u=',umin,'Function value=',PhiMin)
            print('='*32)    
        
        # Restore original distance matrix and store function values
        self._dmat = self.__D
        self.__PhiMin = PhiMin 
        self.Phi = dict(zip(self.__U,Phi))
        
        # Delete the Cplex model
        del self.model 
        
    #---------------------------------------------
    
    def draw_func(self):
        """
        Draw the function F(u). If the function is not
        yet computed, this is done first. 
        """
        if self.Phi is None: self.get_full_func()
        plt.plot(self.__U, self.Phi.values()) 
        plt.xlabel('u') 
        plt.ylabel('Phi(u)') 
        plt.title('Phi(u)') 
        plt.show() 

    #---------------------------------------------
    
    def __init_search(self, meth_name ):
        """
        Initialize search for minimizer of Phi
        by building the p-median model, etc.
        """
        # Build the docplex model
        if self.solver.lower()=='cplex': 
            self.cpxModel(x_continuous=True, weakModel=False)
            # Let Cplex measure wall time not CPU time 
            M = self.model
            M.parameters.clocktype(2)
            # Strengthen optimality tolerance
            M.parameters.mip.tolerances.mipgap.set(0.0)
            M.parameters.mip.tolerances.absmipgap.set(0.0)
            # Restrict number of nodes to be enumerated if limit is set
            if not self.__nodeLim is None: 
                M.parameters.mip.limits.nodes.set( self.__nodeLim )
        
        # Send output on current state to screen
        if self.__screen_output:
            print('='*60)
            print(meth_name)
            print('-'*60)
            print(f"{'Iter':<4s}",f"{'Current u':>11s}",f"{'Objective(u)':>14s}",\
                  f"{'Best u':>11s}",f"{'Objective(u*)':>15s}")
            print('-'*60)           
        
    #---------------------------------------------
    
    def __displayPhi(self, itr, u, Phi ):
        """Displays current function value Phi(u)"""
        if itr==1:    
            print(f"{1:>4d}",f"{u:>11.7f}",f"{Phi:>14.2f}")
        else: 
            print(f"{itr:>4d}",f"{u:>11.7f}",f"{Phi:>14.2f}",\
                  f"{self.__umin:>11.7f}",f"{self.__PhiMin:>15.2f}")
            
    #---------------------------------------------
    
    def __gss(self, LB_u = 0.0, UB_u = None ):
        """
        Golden section search for minimizing Phi(u)
        
        Parameters
        ----------
        LB_u, UB_u : float (UB_u might be None)
            Lower and upper bound on minimizer of Phi(u)
        """      
        self.__init_search('Golden Section Search')
        
        # Interval containing the minimizer
        L, R = 0, len(self.__U)
        if LB_u > 0.0: L = (np.where(self.__U >= LB_u )[0]).min()
        if not UB_u is None and UB_u < self.U[-1]: R = (np.where(self.__U > UB_u)[0]).min()
            
        # Determine the initial four points required by GSS
        u1, u2 = int( R - self.__gratio*(R-L) ), round(L + self.__gratio*(R-L))
        _, Phi_1 = self.__comp_Phi(self.__U[u1])
        facs = self.facilities.copy()
        if self.__screen_output: self.__displayPhi(1, self.__U[u1], Phi_1) 
        _, Phi_2 = self.__comp_Phi(self.__U[u2])
        if Phi_2 < Phi_1:
            self.__PhiMin, self.__umin, facs = Phi_2, self.__U[u2], self.facilities.copy()
        else:
            self.__PhiMin, self.__umin = Phi_1, self.__U[u1]
        if self.__screen_output: self.__displayPhi(2, self.__U[u2], Phi_2)
   
        Phi = dict()
        Phi[u1] = Phi_1 
        Phi[u2] = Phi_2
    
        itr = 2
        max_time = float('inf') if self.__search_time is None else self.__search_time
        while R-L > 2:
            if Phi_1 > Phi_2:
                L  = u1
                u1 = u2
                u2 = ceil( L + self.__gratio*(R-L) ) 
                Phi_1 = Phi_2
                u  = self.__U[u2]
                Phi_2 = Phi.get(u2)
                if Phi_2 is None:
                    itr += 1  
                    _, Phi_2 = self.__comp_Phi(u)
                    Phi[u2] = Phi_2
                Phi_u = Phi_2
            else:
                R  = u2
                u2 = u1
                u1 = int( R - self.__gratio*(R-L) )
                Phi_2 = Phi_1 
                u  = self.__U[u1]
                Phi_1 = Phi.get(u1)
                if Phi_1 is None:
                    itr += 1
                    _, Phi_1 = self.__comp_Phi(self.__U[u1])
                    Phi[u1] = Phi_1
                Phi_u = Phi_1 
            if Phi_u < self.__PhiMin: 
                self.__PhiMin, self.__umin, facs = Phi_u, u, self.facilities.copy()
            if self.__screen_output: self.__displayPhi(itr, u, Phi_u)
            if self.pyWall > max_time: break
        
        if self.pyWall < max_time and R-L == 2 and Phi.get(L+1) is None:
            # Solve last missing problem
            u = self.__U[L+1]
            itr += 1
            _, Phi_u = self.__comp_Phi(u)
            Phi[L+1] = Phi_u
            if Phi_u < self.__PhiMin:
                self.__PhiMin, self.__umin, facs = Phi_u, u, self.facilities.copy()
            if self.__screen_output: self.__displayPhi(itr, u, Phi_u)
       
        if self.__screen_output: print('-'*60)
        
        self.itr = itr 
        self.facilities = facs
        self.Phi = Phi
       
    #---------------------------------------------
    
    def __qfs(self, LB_u=0.0, UB_u=None ):
        """
        Applies quadratic fit search for finding the
        minimizer of the function Phi(u). For a
        good description of quadratic fit search
        see: Kochenderfer, M.J, Wheeler, T.A. (2025).
        Algorithms for Optimization, 2nd edition,
        MIT Press.
        
        Parameters
        ----------
        LB_u, UB_u : float (UB_u might be None)
            Lower and upper bound on minimizer of Phi(u)
        """
        # [a,c] is the interval containing the minimizer
        a, c = 0, len(self.__U)-1
        if LB_u > 0.0: a = (np.where(self.__U >= LB_u )[0]).min()
        if not UB_u is None and UB_u < self.U[-1]: c = (np.where(self.__U > UB_u)[0]).min()
        
        # Initial third point b from [a,b] according to golden section
        b = round(c*(1.0 - self.__gratio))
        
        # Dictionary of function values
        Phi = dict()                           
                             
        # Check if (x,Phi(x)) for x = a, b, c is collinear
        def coLinear():
            if abs(Phi[a]-Phi[c]) < 1.0E-06: return True 
            alpha = (Phi[b]-Phi[c])/(Phi[a]-Phi[c])
            if alpha < 0.0 or alpha > 1.0: return False 
            return True
        
        # Quadratic function through points {(x,Phi(x)): x=a,b,c}
        def qfunc(x):
            q_x = Phi[a]*((x-b)*(x-c))/((a-b)*(a-c)) + Phi[b]*((x-a)*(x-c))/((b-a)*(b-c))\
                  + Phi[c]*((x-a)*(x-b))/((c-a)*(c-b))
            return q_x 
            
        
        # Minimizer of the quadratic function rounded down
        # (not sure if that really works)
        def min_quad():
            if coLinear():
                if Phi[a] < Phi[c]: return a
                return c 
            else:
                aa, bb, cc = a*a, b*b, c*c 
                qmin = (0.5*(Phi[a]*(bb-cc)+Phi[b]*(cc-aa)+Phi[c]*(aa-bb)))/ \
                       ( Phi[a]*(b-c) + Phi[b]*(c-a) + Phi[c]*(a-b) )
                q1, q2 = floor(qmin), ceil(qmin)
                if Phi.get(q1) is None:
                    if Phi.get(q2) is None: 
                        return q2 if qfunc(q2) < qfunc(q1) else q1
                    else:
                        return q1
                elif Phi.get(q2) is None:
                    return q2 
                else: 
                    return q2 if Phi[q2] < Phi[q1] else q1            
              
        self.__init_search('Quadratic Fit Search')
        
        # Compute function values at a, b, and c
        self.__PhiMin = float('inf')
        itr = 0
        for k in (a,b,c):
            if Phi.get(k) is None:
                itr += 1
                u = self.__U[k]    
                _, Phi[k] = self.__comp_Phi(u)
                if Phi[k] < self.__PhiMin: 
                    self.__umin, self.__PhiMin, facs = u, Phi[k], self.facilities.copy()
                if self.__screen_output: self.__displayPhi(itr, u, Phi[k])
         
        max_time = float('inf') if self.__search_time is None else self.__search_time  
        while c-a > 2:
            k = min_quad()
            u = self.__U[k]
            Phi_k = Phi.get(k)
            if Phi_k is None:
                itr += 1
                _, Phi_k = self.__comp_Phi(u)
                if Phi_k < self.__PhiMin: 
                    self.__umin, self.__PhiMin, facs = u, Phi_k, self.facilities
                Phi[k] = Phi_k
            if self.__screen_output: self.__displayPhi(itr, u, Phi_k)
            if k > b:
                if Phi_k > Phi[b]: 
                    c = k
                else:
                    a = b 
                    b = k
            elif k < b:
                if Phi_k > Phi[b]:
                    a = k
                elif k < b: 
                    c = b
                    b = k
            else:
                break
            if self.pyWall > max_time: break
        
        # Check neighbours of of u = self.__U[k]
        for kk in range(k-1,a,-1):
            if self.pyWall > max_time or not Phi.get(kk) is None: break
            u = self.__U[kk]
            itr += 1
            _, Phi_u = self.__comp_Phi(u)
            Phi[kk] = Phi_u
            if Phi_u < self.__PhiMin:
                self.__PhiMin, self.__umin, facs = Phi_u, u, self.facilities.copy()
            else:
                break
            if self.__screen_output: self.__displayPhi(itr, u, Phi_u)
        for kk in range(k+1,c,1):
            if self.pyWall > max_time or not Phi.get(kk) is None: break
            u = self.__U[kk]
            itr += 1
            _, Phi_u = self.__comp_Phi(u)
            Phi[kk] = Phi_u
            if Phi_u < self.__PhiMin:
                self.__PhiMin, self.__umin, facs = Phi_u, u, self.facilities.copy()
            else:
                break
            if self.__screen_output: self.__displayPhi(itr, u, Phi_u)
        
        if self.__screen_output: print('-'*60) 
        self.itr = itr 
        self.facilities = facs  
        self.Phi = Phi      
        
    #---------------------------------------------

    def __solveMIP(self):
        """
        Obtains a solution to the fair p-median problem
        by simply solving the formulation as a mixed
        integer linear program given in Filippi et al.
        (2021).
        """
        
        # Build the base model as the ordinary p-median problem
        self.cpxModel(x_continuous=True, weakModel=False)
        M = self.model 
        
        # Restrict number of nodes to be enumerated if limit is set
        if not self.__nodeLim is None:
            M.parameters.mip.limits.nodes.set( self.__nodeLim )
      
        D = self._dmat           # distance matrix
        w = self._w              # customer weights
        x = self.x               # allocation variables
        m, n = self._m, self._n  # customers, facilities     
        
        # Add the continuous variable u and v(i)
        u = M.continuous_var()
        v = M.continuous_var_dict(m)
        beta = M.continuous_var()
        
        # Add the additional constraints
        M.add_constraint_( beta >= u + M.sum( w[i]*v[i] for i in range(m))/self.__kbeta) 
        M.add_constraints_(u+v[i]-M.sum(D[i,j]*x[i,j] for j in range(n)) >= 0\
                           for i in range(m))
        
        # Objective function as weighted sum of inequity and distance
        distance = M.sum( w[i]*D[i,j]*x[i,j] for i,j in x.keys() ) / self.__totW
        M.minimize( self.obj_weight[0]*beta + self.obj_weight[1]*distance )
        if self.__screen_output:
            print('-'*50)
            print('Solving MIP model of the fair p-median problem using Cplex')
            print('-'*50)
        shut_up = self.silent 
        self.silent = not self.screen_output
        self.cpxSolve(save_facilities=True, save_assignment=True) 
        self.silent = shut_up
        # cpxSolve stores the Cplex objective value in self.wdist
        self.__PhiMin = self.wdist
        # Obtain the actual total weighted distance in the solution
        dists = np.fromiter((self._dmat[i,self.assigned[i]] for i in range(self._m)),dtype=float)
        self.wdist = (self._w * dists).sum()
        # Obtain value of the conditional beta mean
        self.__beta_mean = self.__PhiMin - self.__obj_weight[1]*self.wdist/self.__totW
        self.__beta_mean /= self.obj_weight[0]
        
        #tmp = self.__obj_weight[0]*self.__beta_mean + self.__obj_weight[1]*self.wdist/self.__totW
     
    
    #---------------------------------------------
    
    def __parametric_pmed(self, use_gss=True, LB_u=0.0, UB_u=None ):
        """
        Solve the "fair p-median problem as a parametric p-median
        problem with distances depending on a single parameter u.
        
        Parameters
        ----------
        gss : bool
            Determines the search method to be applied.
            If True, Golden Section search is used.
            If False, Quadratic Fit search is used.
        LB_u : float 
            Lower bound on the minimizer of function Phi(u)
        UB_u : None or float
            Upper bound on the minimizer of function Phi(u)    
        """
        # Set computational performance measures
        self.pyCPU, self.pyWall = 0.0, 0.0 
        self.cpxWall, self.cpxTick = 0.0, 0.0 
        self.cpxNodes = 0
        
        # Obtain list of possible u-values sorted increasing
        if self.__U is None: self.__U = np.unique( self._dmat )
        
        # Keep copy of original distance matrix as the latter
        # will be overwritten in the course of the method.
        self.__D = self._dmat.copy()
        
        # Solve the problem using golden section search
        if use_gss:
            self.__gss(LB_u=LB_u, UB_u=UB_u)
        else:
            self.__qfs(LB_u=LB_u, UB_u=UB_u)
        
        # Remember computation time and number of iterations
        self.ctime = (self.pyCPU, self.pyWall)
        self.cpx_time = self.cpxWall 
        self.cpx_ticks = self.cpxTick 
        self.nodes_processed = self.cpxNodes
        
        # Restore original distance matrix
        self._dmat = self.__D
             
        # Compute the actual weighted distances and the conditional
        # beta-mean of the obtained solution. 
        self.assigned = self.get_assigned( self.facilities )
        dists = np.fromiter((self._dmat[i,self.assigned[i]] for i in range(self._m)),dtype=float)
        self.wdist = (self._w * dists).sum()
        self.__beta_mean = self.__umin + (self._w*np.maximum(0,dists - self.__umin)).sum()/self.__kbeta
        
        # Check for correctness of PhiMin 
        tmp = self.__obj_weight[0]*self.__beta_mean + self.__obj_weight[1]*self.wdist/self.__totW
        if abs(tmp - self.__PhiMin) > 1.0E-04:
            print('Hups: something wrong')
        
    #---------------------------------------------
    
    def fair_solver(self, method='pmedian-gss', LB_u=0.0, UB_u=None ):
        """
        Solve the fair p-median problem
        
        Parameters
        ----------
        method : str 
            Specifies the solution method to be applied. 
            If equal to 'pmedian', the default it is
            solved as a sequence of p-median problems.
            If equal to 'mip' it is solve as a mixed
            integer linear program using Cplex.
        LB_u : float
            Lower bound on the minimizer of function Phi(u).
            Default is 0.0 (that is no known lower bound)
        UB_u : None or float
            Upper bound on the minimizer of function Phi(u).
            Default is None, that is no upper bound known.
        
        Remark
        ------
        Assume the problem has been solved for a given value β
        for the conditional β-mean. Assume that u(β) results
        then as the minimizer of Phi(u). That can be used
        as follows if thereafter the same problem but with
        different value, say β', of the parameter has to be
        solved.
        
        * If β' > β, then u(β') <= u(β) so that we may let
          UB_u = u(β) for computing the new optimal solution.
        * If β' < β, then u(β') >= u(β) so that we may let
          LB_u = u(β) for computing the new optimal solution.
        """
        if method.lower() == 'mip':
            self.__solveMIP()
        else:
            self.__parametric_pmed(use_gss='gss' in method.lower(), LB_u=LB_u, UB_u= UB_u)
            