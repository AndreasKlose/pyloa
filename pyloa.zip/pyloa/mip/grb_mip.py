"""
    Defines a wrapper class for the gurobipy Model class.
"""
import numpy as np
from gurobipy import Model, Column, GRB, LinExpr, quicksum as qsum
            
#--------------------------------------------------------------------------

class GRBmodel:
    """
    Wraps some methods and attributes of the gurobipy model class for
    the purposes of synchronizing function names with docplex.      
    """
    def __init__(self, name=None  ):
        """
        Parameters
        ----------
        name : str, onal
            Name of the model, default is None
        """             
        self.__model = Model() if name is None else Model(name)
        """Instance of the gurobipy Model class."""
        
        self.__callbck = None 
        """Instance of a callback class."""
        
        self.__wheres = None 
        """List of wheres when to to use a callback function."""
        
    #---------------------------------------------
    
    def set_callback( self, callbck, contxtmsk=None, wheres=None ):
        """
        Set callback class for the purposes ('wheres') defined
        by wheres.
        
        Parameters
        ----------
        callbck : class 
            The class to be called for the callback.
        contxtmask : int 
            Cplex's indicator for the context in which the
            callback might be called.
        wheres : list of int
            GuRoBi's list of 'where' codes to be enabled in
            the callback.
        """
        self.__callbck = callbck 
        self.__wheres = wheres
            
    #---------------------------------------------
    
    def in_relaxation(self, where ):
        """
        Return True if GuRoBi solver calls callback
        after solving the relaxation.
        """
        return where==GRB.Callback.MIPNODE and \
               self.__model.cbGet(GRB.Callback.MIPNODE_STATUS)==GRB.OPTIMAL
     
    #---------------------------------------------
    
    def cbGetNodeRel( self, dvars ):
        """
        Return the relaxation's solution for the decision variables 
        dvars at the current branch-and-cut node.
        
        Parameters
        ----------
        dvars : sequence of decision variables.
        
        Returns
        -------
        Solution values to the specified variables as numpy array of float.
        """
        return np.fromiter(map(lambda v : self.__model.cbGetNodeRel(v),dvars),dtype=float)
    
    #---------------------------------------------
    
    def cbGetNodeRealKeys( self, dvars, keys ):
        """
        Return the relaxation's solution for decision 
        variables from a dictionary and the specified
        dictionary keys.
        
        Parameters 
        ----------
        dvars : dict of decision variables.
        keys  : sequence of dictionary keys. 
        
        Returns
        -------
        Solution values for the decision variables with the
        given keys as a numpy array of float. 
        """
        return np.fromiter(map(lambda k : self.__model.cbGetNodeRel(dvars[k]),keys),dtype=float)
     
    #---------------------------------------------
    
    def cbCut(self, cut ):
        """
        Add a global user cut from a callback to the solver.
        
        Parameters
        ----------
        cut : GuRoBi linear constraint 
           The object representing the cut as a
           linear constraint in the form:
           lhs R rhs, where R is <=, =, or >=.
        """
        self.__model.cbCut( cut )
  
    #---------------------------------------------
     
    def addConstraint(self, constr, return_constr=False ):
        """
        Adds the single constraint constr to the model.
        
        Parameters
        ----------
        constr : GuRoBi temporary constraint object
            The constraint to be included to the model.
        
        Returns
        -------
        cnstr : gurobipy.tempConstr
            The temporary form of the constraint included to the model.
        return_constr : bool 
            If True, the constraint object instance
            is returned.
        """             
        c = self.__model.addConstr(constr)
        if return_constr: return c
              
    #---------------------------------------------
    
    def addConstraints(self, constrs, return_constr=False ):
        """
        Adds several constraints to the model.
        
        Parameters
        ----------
        constrs : iterable of gurobipy.Constr or gurobipy.tempConstr    
            The iterable or generator expression of constraints to be included.        
        return_constr : Bool
            If True, the list of the added constraints is returned.
            
        Returns
        -------
        None or the list of the added constraints. Note that this
        are temporary constraints in GuRoBi until the model is updated.
        """   
        c = self.__model.addConstrs( constrs )
        if return_constr: return list( c.values() )
        
    #---------------------------------------------
    
    def addQuadConstrs(self, constrs, return_constr=False):
        """
        Add a bunch of quadratic constraints to the model.
        Is actually the same as addConstraints, as GuRoBi
        does not care if the constraints are linear or
        quadratic.
        
        Parameters
        ----------
        constrs: iterable of constr  
            The quadratic constraint expressions.    
        return_constr : Bool
            If True, the added constraints are returned.
        """
        c = self.__model.addConstrs( constrs )
        if return_constr : return c
     
    #---------------------------------------------
    
    def set_rhs(self, constr, rhs ):
        """
        Sets a constraints "constr" right-hand
        side to a value of "rhs".
        
        Parameters
        ----------
        constr : gurobipy.Constr
            The constraint where to adjust the rhs.
        rhs : int or float
            The (new) right-hand side value.
        """
        constr.setAttr( 'rhs', rhs )
        
    #---------------------------------------------
    
    def get_rhs(self, constr):
        """
        Return the linear constraint's constr right-hand side.
         """  
        return constr.getAttr('rhs')
    
    #---------------------------------------------
    
    def minimize (self, expr ):
        """
        Sets the objective function of the underlying GuRoBi model 
        to be the minimization of the expression expr. This is
        an alias to gurobipy.model.SetObjetive(expr, GRB.MINIMIZE)
                
        Parameters
        ----------
        expr : gurobi LinExpr
            Single objective function to be minimized.
        """
        self.__model.setObjective(expr,GRB.MINIMIZE)
        
    #---------------------------------------------
    
    def maximize (self, expr ):
        """
        Sets the objective function of the underlying GuRoBi model 
        to be the maximization of the expression expr. This is
        an alias to gurobipy.model.SetObjetive(expr, GRB.MAXIMIZE)
                
        Parameters
        ----------
        expr : gurobi LinExpr
            Single objective function to be minimized.
        """
        self.__model.setObjective(expr,GRB.MAXIMIZE)
             
    #------------------s---------------------------
    
    def __getObjVal(self):
        """
        Return the objective value of the solution
        to the underlying GuRoBi MIP model (and
        None if there is no solution).
        """
        try:
            obj = self.__model.ObjVal 
        except:
            return None
        return obj 
       
    #---------------------------------------------
    
    def addVar(self, lb=0.0, ub=float('inf'), obj=0.0, vtype=None,\
               name='', constr=None, coeffs=None ):
        """
        Adds a single variable to the model.
        
        Parameters
        ----------
        lb : float
            Lower bound for the variable. Default: 0.0
        ub : float
            Uppper bound on the variable. Default: None
        obj : float
            The variables objective coefficient.
        vtype : None or str
            If None, a continuous variable is created. 
            Otherwise, if vtype='B' a binary and if
            vtype='I' an integer variable.
        name : str 
            Name to be given to the variable. Default is None.
        constr : None or a sequence of constraints
            Sequence of constraint to which the variable should 
            be added.
        coeffs : None or a single float/int or an iterable of float/int.
            If coeffs is a single float or int, the variable
            is added to all constraints from the above sequence
            of constraints with the same coefficient 'coeffs'.
            If coeffs is an iterable, the variable is included
            with the specified coefficient to the given sequence
            of constraints. Make sure that both sequences are
            of the same length.
            
        Returns
        -------
        An instance of class Var (gurobipy).
        """
        col= None  
        if not (constr is None or coeffs is None): 
            col = Column(list(coeffs),list(constr)) if hasattr(coeffs,'__iter__') \
                  else Column( [coeffs]*len(constr),list(constr) )
            
        if vtype is None:
            return self.__model.addVar( lb=lb, ub=ub, obj=obj, vtype=GRB.CONTINUOUS,\
                                       name=name, column=col )
        if vtype.upper()=='B': 
            return self.__model.addVar(vtype=GRB.BINARY, obj=obj, name=name, column=col )
        return self.__model.addVar(lb=lb, ub=ub, obj=obj, vtype=GRB.INTEGER, name=name,\
                                   column=col)
     
    #---------------------------------------------
    
    def addVars(self, indices, lb=0.0, ub=float('inf'), vtype=None, name=None ):
        """
        Adds a dictionary of variables with keys
        indices to the MIP model.
        
        Parameters
        ----------
        indices : iterable 
            Sequence of indices to be used as 
            keys of the dictionary.
        lb : int or float or iterable of int or float
            Lower bounds to be applied for the variables.
            If None, lower bounds are zero.
        ub : int or float or iterable of int or float
            Upper bounds to be applied for the variables.
            If None, no upper bounds are imposed.
        vtype : None or str
            Type of the variables. If None, it's
            continuous variables, if 'B' binary
            variables, if 'I' integer variables.
        name : None or str 
            If not None, variables are named as name[index].
            
        Returns
        -------
        v : dict
            The dictionary of MIP model variables.
        """
        nme = '' if name is None else name
        if vtype is None: return self.__model.addVars( indices, lb=lb, ub=ub, name=nme )
        if vtype.upper()=='B': 
            return self.__model.addVars( indices, vtype=GRB.BINARY, name=nme )
        return self.__model.addVars( indices, lb=lb, ub=ub, vtype=GRB.INTEGER, name=nme )    
    
    #---------------------------------------------
    
    def addVarMatrix(self, rows, cols, lb=0.0, ub=float('inf'), vtype=None, name=None ):
        """
        Create and return a rows x cols matrix of variables
        of type vtype.
    
        Parameters
        ----------
        rows, cols : int 
            Number of rows and columns of the matrix. 
        lb : int or float or iterable of int or float
            Lower bounds to be applied for the variables.
            If None, lower bounds are zero.
        ub : int or float or iterable of int or float
            Upper bounds to be applied for the variables.
            If None, no upper bounds are imposed.
        vtype : None or str
            Type of the variables. If None, it's
            continuous variables, if 'B' binary
            variables, if 'I' integer variables.
        name : None or str 
            If not None, variables are named as name[index].
            
        Returns
        -------
        v : dict
            The dictionary of MIP model variables.
        """
        nme = '' if name is None else name
        if vtype is None: 
            return self.__model.addVars( rows, cols, lb=lb, ub=ub, name=nme ) 
        if vtype.upper()=='B': 
            return self.__model.addVars( rows, cols, vtype=GRB.BINARY, name=nme )
        return self.__model.addVars( rows, cols, lb=lb, ub=ub, vtype=GRB.INTEGER, name=nme )
    
    #---------------------------------------------
    
    def addVarCube(self, indx, lb=0.0, ub=float('inf'), vtype=None, name=None):
        """
        Creates and return a dictionary of variables indexed by the
        the three indices.
    
        Parameters
        ----------
        indx : tuple of three int 
            Tuple of the three indices.
        lb : int or float or iterable of int or float
            Lower bounds to be applied for the variables.
            If None, lower bounds are zero.
        ub : int or float or iterable of int or float
            Upper bounds to be applied for the variables.
            If None, no upper bounds are imposed.
        vtype : None or str
            Type of the variables. If None, it's
            continuous variables, if 'B' binary
            variables, if 'I' integer variables.
        name : None or str 
            If not None, variables are named as name[index]. 
            
        Returns
        -------
        v : dict
            The dictionary of MIP model variables.
        """
        if vtype is None: 
            return self.__model.addVars(indx[0], indx[1], indx[2], lb=lb, ub=ub, name=name) 
        if vtype.upper()=='B': 
            return self.__model.addVars( indx[0], indx[1], indx[2], name=name )
        return self.__model.addVars( indx[0], indx[1], indx[2], lb=lb, ub=ub, name=name )   
    
    #---------------------------------------------
    
    def set_vartype(self, dvar, vtype ):
        """
        Set the type of the decision variable var
        to the type vtype.
        
        Parameters
        ----------
        dvar : gurobipy.Var object
            The variable whose type should be set.
        vtype : str 
            The type to which the variables should be set:
            'B' for binary, 'I' for integer, 'C' for 
            continuous.
        """
        dvar.Vtype = vtype 
     
    #---------------------------------------------
    
    def change_var_types(self, dvars, vtype ):
        """
        Changes the type of a collection of variables.
        
        Parameters
        ----------
        dvars : iterable of decision variables
            The variables for which the type should
            be changed.
        vtype : an iterable of variable types or 
            The single type to which the variables
            should be changed.
        """
        try:
            vitr = iter(vtype)
            for v in dvars: v.VType = next(vitr)
        except:
            for v in dvars: v.VType = vtype 
        
    #---------------------------------------------
    
    def change_upper_bounds( self, dvars, ub ):
        """
        Changes the upper bounds of a collection of variables.
        
        Parameters
        ----------
        dvars : iterable of decision variables
            The variables for which the type should
            be changed.
        ub : an iterable or a single number specifying
            the new upper bound(s).
        """
        try:
            u = iter(ub)
            for v in dvars: v.ub = next(u)
        except:
            for v in dvars: v.ub = ub

#---------------------------------------------
    
    def change_lower_bounds( self, dvars, lb ):
        """
        Changes the lower bounds of a collection of variables.
        
        Parameters
        ----------
        dvars : iterable of decision variables
            The variables for which the type should
            be changed.
        lb : an iterable or a single number specifying
            the new lower bound(s).
        """
        try:
            l = iter(lb)
            for v in dvars: v.lb = next(l)
        except:
            for v in dvars: v.lb = lb

    #---------------------------------------------

    def sum(self, exprs ):
        """
        Returns the sum of a list or iterable of 
        expressions using gurobipy's quicksum.
        """
        return qsum(exprs)
    
    #---------------------------------------------
    
    def mip_tol(self, absgap=-1.0, relgap=-1.0, int_tol=-1.0, feas_tol=-1.0 ):
        """
        Set the MIP solver's absolute  and relative 
        optimality tolerances to the values absgap and 
        relgap, resp.
        
        Parameters
        ----------
        absgap, relgap, int_tol, feas_tol : float
            Non-negative floating point numbers. If negative, the 
            tolerance is not set. absgap and relgap are the
            absolute and relative optimality tolerance, int_tol
            is the tolerance for integrality, and feas_tol the
            feasibility tolerance for the simplex method.
        """
        if not absgap < 0.0:
            self.__model.params.MIPGapAbs = absgap
        if not relgap < 0.0:
            self.__model.params.MIPGap = relgap
        if not int_tol < 0.0:
            self.__model.params.IntFeasTol = int_tol
        if not feas_tol < 0.0:
            self.__model.params.FeasibilityTol = feas_tol
    
    #---------------------------------------------
    
    def optim( self ):
        """
        Calls the solver (gurobipy.model.optimize) for
        solving the current MIP model.
                               
        Returns
        -------
        success : bool 
            True, if a feasible or optimal solution was found.
        """
        if self.__wheres is None:
            self.__model.optimize( self.__callbck )
        else:
            # Requires GuRoBi 13
            self.__model.optimize( self.__callbck, wheres=self.__wheres )
        return self.__model.SolCount > 0
        
    #---------------------------------------------
    
    def get_solution( self, X, keep_zeros=True, precision=1.0E-06 ):
        """
        Returns the solution values of variables X.
        
        Parameters
        ----------
        X : dict
            Dictionary of docplex.mp.dvar
        keep_zeros : bool
            If True, the default, all solution 
            values to variables X are returned.
            Otherwise, only non-zero values are
            returned.
        precision : float (positive)
            Figures smaller in magnitude than precision are seen as
            zeros.

        Returns
        -------
        Dictionary of solution values for the variables in the dictionary X.
        """
        try:
            sol = self.__model.getAttr("X",X)
            if keep_zeros: return sol 
            return dict(filter(lambda itm : abs(itm[1]) >= precision, sol.items()))
        except:
            return None
        
    #---------------------------------------------
    
    def get_dual_values(self, constr ):
        """
        Returns the list/sequence of dual variables to
        the linear constraints in the list/sequence
        of linear constraints constr. 
        """
        return list( c.pi for c in constr )
        
    #---------------------------------------------
    
    def getVars(self):
        """
        Alias for gurobipy.model.getVars, which returns
        a list of the model's variables.
        """
        return self.__model.getVars()
    
    #---------------------------------------------
    
    def getConstraints(self):
        """
        Alias for gurobipy.model.getConstr, which returns
        a list all linear constraints in the model.
        """
        return self.__model.getConstrs()
    
    #---------------------------------------------

    def getObjective(self):
        """
        Alias for gurobioy.model.getObjective, which
        returns the objective expression.
        """
        return self.__model.getObjective()
            
    #---------------------------------------------
    
    def reduced_costs(self, dvars ):
        """
        Returns the reduced cost of the decision variables
        dvars.
        
        Parameters
        ----------
        dvars: iterable/sequence of variables
            Sequence of decision variables.
        
        Returns
        -------
        rc : list of float
            The list of the variables' reduced cost.
        """
        return list( map( lambda x : x.RC, dvars ) )
    
    #---------------------------------------------
    
    def chgCoeff(self, constr, dvar, coef=0.0 ):
        """
        Change the coefficient of variable dvar in
        the linear constraint constr to value coef.
        
        Parameters
        ----------
        constr : gurobipy Constr
            The constraint to be adjusted.
        dvar : gurobipy Var
            The decision variable where to change
            the coefficient.
        coef : int or float
            The value of the (new) coefficient.
        """
        self.__model.chgCoeff(constr, dvar, coef)
   
    #---------------------------------------------
    
    def chgCoeffs(self, constr, coeffs ):
        """
        Changes coefficients of a number of variables
        in the linear constraint constr.
        
        Parameters
        ----------
        coeffs : iterable/sequence of pairs
             Iterable/sequence of variable-coefficient pairs.
        constr : gurobipy.Constr
            The constraint to be adjusted.
        """
        #for d,c in coeffs: self.__model.chgCoeff(constr, d, c)
        rhs, sense, nme = constr.RHS, constr.Sense, constr.ConstrName 
        self.__model.remove( constr )
        x, a = zip(*coeffs) # variables and their coefficients
        lhs = LinExpr( a,x ) 
        if sense=='<':
            cstr = self.__model.addConstr( lhs <= rhs, name=nme)
        elif sense=='>':
            cstr = self.__model.addConstr( lhs >= rhs, name=nme )
        else:
            cstr = self.__model.addConstr( lhs == rhs, name=nme )
        return cstr
         
    #---------------------------------------------
      
    def export_model ( self, lp_file ):
        """
        Exports the model to a model file of type "lp". 
        
        Parameters
        ----------
        lp_file : str    
            Name of the file where to write the model.
        """
        self.__model.write( lp_file )
        
    #---------------------------------------------
    
    def update(self):
        """
        gurobipy.model.update.
        """
        self.__model.update() 
       
    #---------------------------------------------
    
    def end ( self ):
        """
        Clean up the GuRoBi IP model by calling its "close" method.
        """
        if not self.__model is None: self.__model.close()
        self.__model = None
    
    #---------------------------------------------
    
    def terminate(self):
        """
        Terminate GuRoBi's computation on the model from a callback
        """
        self.__model.terminate()
        
    #---------------------------------------------
    
    @property 
    def mipModel(self):
        """
        Return the instance of the gurobipy Model class.
        """
        return self.__model 
    
    @property
    def ObjVal(self):
        """Objective value of a solution to the model."""
        return self.__getObjVal()
    
    @property
    def ObjBound(self):
        """
        Best bound on (lower for minimization, upper for
        maximization) on the optimal objective value.
        """
        return self.__model.ObjBound 
    
    @property
    def runtime(self):
        """Return computation time used to solve the model."""
        return self.__model.runtime
    
    @property 
    def dettime(self):
        """Return the deterministic time. For GuRoBi, this
        is the model attribute Work, a figure that roughly
        corresponds to a second on a single thread."""
        return self.__model.Work
    
    @property
    def status(self):
        """Return the model status, cf. gurobipy.Model.status."""
        return self.__model.status    
    
    @property 
    def nodeCount(self):
        """Return the NodeCount, i.e. the number of branch-and-cut 
        nodes explored in GuRoBi's most recent optimization."""
        return self.__model.NodeCount 
    
    @property 
    def infinity(self):
        return GRB.INFINITY
            
    @property 
    def MIPGapAbs(self):
        """Parameter MIPGapAbs."""
        return self.__model.params.MIPGapAbs
    
    @MIPGapAbs.setter 
    def MIPGapAbs(self, value ):
        """Parameter MIPGapAbs."""
        if value >= 0.0: self.__model.params.MIPGapAbs = value
    
    @property 
    def MIPGap(self):
        """Parameter MIPGap."""
        return self.__model.params.MIPGap
    
    @MIPGap.setter 
    def MIPGap(self,value):
        """Parameter MIPGap."""
        if value >= 0.0: self.__model.params.MIPGap = value 
    
    @property 
    def IntFeasTol(self):
        """Parameter IntFeasTol."""
        return self.__model.params.IntFeasTol
    
    @IntFeasTol.setter 
    def IntFeasTol(self, value):
        """Parameter IntFeasTol."""
        if 0 <= value < 1: self.__model.params.IntFeasTol=value
    
    @property
    def FeasibilityTol(self):
        """Parameter FeasibilityTol."""
        return self.__model.params.FeasibilityTol
    
    @FeasibilityTol.setter 
    def FeasibilityTol(self,value):
        """Parameter FeasibilityTol."""
        if 0 <= value < 1: self.__model.params.FeasibilityTol = value 
    
    @property 
    def MIQCPMethod(self):
        """Parameter mip.strategy.miqcpstrat."""
        return self.__model.params.MIQCPMethod
    
    @MIQCPMethod.setter
    def MIQCPMethod(self, strategy ):
        """Parameter mip.strategy.miqcpstrat to value strategy-1."""
        self.__model.params.MIQCPMethod = strategy - 1
        
    @property 
    def timelimit(self):
        """Time limit for the MIP solver."""
        return self.__model.params.timelimit  
    
    @timelimit.setter 
    def timelimit(self, value):
        """Set the time limit for the MIP solver."""
        self.__model.params.timelimit = value if value > 0 else float('inf')   

    @property 
    def nodelimit(self):
        """Node limit for the MIP solver."""
        return self.__model.params.nodelimit  
    
    @nodelimit.setter 
    def nodelimit(self, value):
        """Set the time limit for the MIP solver.""" 
        self.__model.params.nodelimit = value if value >= 0 else float('inf')   
        
    @property 
    def upper_cutoff( self ):
        """Upper cutoff value."""
        return self.__model.params.cutoff
    
    @upper_cutoff.setter 
    def upper_cutoff( self, value ):
        """Set an upper cutoff value."""
        self.__model.params.cutoff = value
        
    @property 
    def lower_cutoff( self ):
        """Lower cutoff value."""
        return self.__model.params.cutoff
    
    @lower_cutoff.setter 
    def lower_cutoff( self, value ):
        """Set a lower cutoff value."""
        self.__model.params.cutoff = value
    
    @property 
    def lowerObjStop(self):
        """
        GuRoBi parameter BestObjStop (for minimization).
        """
        return self.__model.params.BestObjStop
    
    @lowerObjStop.setter 
    def lowerObjStop(self, value ):
        """
        Set GuRoBi parameter BestObjStop to the given value.
        """
        self.__model.params.BestObjStop = value 
   
    @property
    def log_output(self):
        """True if value of gurobiy.model.OutputFlag=1"""
        return self.__model.params.OutputFlag > 0

    @log_output.setter
    def log_output(self, on_off):
        """If True, gurobipy.model.OutputFlag is set to 1."""
        self.__model.params.OutputFlag = int(on_off)
 
    @property 
    def mipStrategy(self):
        """Dynamic search switch, does not exist for GuRoBi"""
        return 0
    
    @mipStrategy.setter 
    def mipStrategy(self, value ):
        """Dynamic search switch, does not exist for GuRoBi."""
        pass 
        
    @property 
    def mipEmphasis(self):
        """GuRoBi parameter MIPFocus. Mimic thereby the
        settings for Cplex: 0 = Balanced (default), 1 = Emphasise 
        feasibility, 2 = Emphasis optimality, 3 = Emphasis the bound,
        4 = HIDDENFEAS does not exist for GuRoBi."""
        return self.__model.params.MIPFocus
    
    @mipEmphasis.setter 
    def mipEmphasis(self, value ):
        """Set GuRoBi parameter MipFocus to value. Mimic thereby the
        settings for Cplex: 0 = Balanced (default), 1 = Emphasise 
        feasibility, 2 = Emphasis optimality, 3 = Emphasis the bound,
        4 = HIDDENFEAS does not exist for GuRoBi."""
        if value in (0,1,2,3): self.__model.params.mipFocus=value
    
    @property 
    def lbHeur(self):
        """Dummy. GuRoBi has no local branching heuristic."""
        return 0
    
    @lbHeur.setter 
    def lbHeur(self, value ):
        """Dummy. GuRoBi has no local branching heuristic."""
        pass 
        
    @property 
    def cuts(self):
        """GuRoBi parameter cuts,  where -1 means automatic
        cut generation, 0 means cuts are switched off, 1 for
        moderate generation of certain cuts, 2 for agressive
        cut generation and 3 for very aggressive cut generation."""
        return self.__model.params.Cuts 
               
    @cuts.setter 
    def cuts( self, value ):
        """
        Set GuRoBi parameter Cuts to value, where -1 means automatic
        cut generation, 0 means cuts are switched off, 1 for
        moderate generation of certain cuts, 2 for agressive
        cut generation and 3 for very aggressive cut generation.
        """
        if value in (-1,0,1,2,3): self.__model.params.Cuts = value 
    
    @property
    def doBenders( self ):
        """Dummy. GuRoBi has no built-in Benders."""
        return -1
    
    @doBenders.setter 
    def doBenders(self, value ):
        """Dummy. GuRoBi has no built-in Benders."""
        pass 
       
    @property 
    def id_relaxation(self):
        """
        Return GRB.Callback.MIPNODE.
        """
        return GRB.Callback.MIPNODE

    @property 
    def cb_MIPSOL(self):
        """Return the constant GRB.Callback.MIPSOL."""
        return GRB.Callback.MIPSOL
    
    @property
    def candidate_objective(self):
        """Return objective value of a candidate solution."""
        return self.__model.cbGet(GRB.Callback.MIPSOL_OBJ)
    
    @property
    def incument_objective(self):   
        """Return the incumbent solution's objective value."""
        return self.__model.cbGet(GRB.Callback.MIPSOL_OBJBST)
