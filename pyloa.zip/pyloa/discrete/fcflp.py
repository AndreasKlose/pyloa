"""
    Module discrete.fcflp of package pyloa:
    Methods for solving the a capacitated facility location problem
    with an equity objective.
"""
import numpy as np
import matplotlib.pyplot as plt
from itertools import product
from pyloa.discrete.cflp import CFLP
from docplex.mp.model import Model 

#--------------------------------------------------------------------------

class FCFLP( CFLP ):
    """
    Class implementing methods for solving the capacitated facility
    location problem with an equity objective. This type of a CFLP is a 
    tri-objective facility location problem. Its objective function is the 
    weighted sum of total fixed facility costs, the total travel distances 
    (supply cost), and a measure of inequity in the distances to be travelled 
    by the clients.The inequity measure is analogue to the conditional value
    of risk known, a coherent risk measure known from finance. Ogryzcak and
    Zawadski (2002) call this meaure the conditional β-mean. It is defined as 
    the average distance the 100*β% demand units travelling the longest distance
    are travelling to the facility from which they get demand. The problem
    has been introduced by Givler Chapman and Mitchell (2018). For a given demand 
    allocation x(j,i) of customer points i to facilities j with distance (unit cost) 
    of c(j,i), the conditional β-mean Mβ(x) is obtained by solving
     
    .. math::
    
        M_\\beta(x) = 1/(\\beta D) & \\max  \\sum_i\\sum_j c_{ji} z_{ji} \\\\
                    \\text{s.t.: } & \\sum_i\\sum_j z_{ji} = D\\beta  \\\\
                                   & 0 \\le z_{ji} \\le d_i x_{ji} \\quad\\forall\\,j,i
    
    or, if we take the dual with dual variables :math:`u` and :math:`v_{ji}`,
    
    .. math::
    
        M_\\beta(x) =  \\min & (D\\beta)u + \\sum_i\\sum_j d_i x_{ji}v_{ji} \\\\
             \\text{s.t.: }  & u + v_{ji} \le c_{ji}/(D\\beta) \\\\
                             & v_{ji} \ge 0 \\quad\\forall\\,j,i\\,.
                       
    Observe that :math:`v_{ji} = \\max\\{0, c_{ji}/(D\\beta) - u\\}` in any optimal 
    solution. The above dual program thus reduces to 
    
    .. math::
    
        M_\\beta(x) =  \\min_u \\Bigl \\{ (D\\beta)u + \\sum_i\\sum_j d_i \\max\\{0, c_{ji}/(D\\beta) - u \\}\\Bigr\\}
    
    From the above, one can immediately see the one-to-one correspondence to the
    CVar risk measure. The CFLP with equity objective is then to minimize the function
    
    .. math::
    
        F(u) = (D\\beta)u + \\min \\sum_j f_j y_j + \\sum_i\\sum_j d_i c_{ji}(u)x_{ji}
    
    over the possible optimal values of the dual variable u. The above
    minimum is thereby taken over the feasible solutions to the CFLP. Note that F(U)
    is may not be convex and can show local minima that are not global minima. 
    The fixed cost of facility j are denoted :math:`f_j`. The total fixed cost 
    have objective weight equal to 1. The unit supply cost above are 
    parametrized by the dual variable u and equal
    
    .. math::
    
        c_{ji}(u) = \\omega_1 c_{ji} + \\omega_2 \\max\\{0, c_{ji}/(D\\beta) - u \\}
    
    
    whereby :math:`\\omega_1` and :math:`\\omega_2` are the objective weights for the 
    travel distances and a solution's "inequity". Minimizing :math:`F(u)` over u is the
    time being done via Golden Section Search or Ternary Search. The set of possible optimal 
    u-values is :math:`U=\\{c_{ji}/(D\\beta)\\forall\\,j,i\\}`. Note that the optimal u is 
    decreasing with increasing value of β. Hence, if an optimal u=u' is known for given 
    β=β', we can limit the search for optimal u and given :math:`\\beta \\le \\beta'` to 
    values of u not smaller than u', whereas an optimal u for a :math:`\\beta \\ge \\beta'` 
    is no larger than u'.
    
    References
    ----------
    Filippi, C., Guastaroba, G., Speranza, M. G. (2021). On single-source capacitated 
    facility location with cost and fairness objective. European Journal of Operational 
    Research, 289, 959-974.
    
    Filippi, C., Guastaroba, G., Huerta-Muñoz, D.L., Speranza. M.G (2021). A kernel search 
    heuristic for a fair facility location problem. Computers & Operations Research, 132
    
    Givler Chapman, A., Mitchell J.E. (2018). A fair division approach to humanitarian 
    logistics inspired by conditional value-at-risk, Annals of Operations Research 262:133-151.
    
    Ogryczak, W. (2000). Inequality measures and equitable approaches to location problems. 
    European Journal of Operational Research, 122, 374-391.
    
    Ogryczak, W. and Zawadzki, M. (2002). Conditional median: A parametric solution concept 
    for location problems. Annals of Operations Research, 110, 167–181.
    """
 
    def __init__( self, fname=None, formt='CFL-GK', unitCost=True, scale=1, \
                  d=None, s=None, f=None, c=None ):
        """
        Creates an instance of the CFLP with equity objective. The parameter β for the 
        conditional β-mean has default value of 0.1, but can be changed using the property 
        "beta". The objective weights are equal to 1 for the fixed cost, 1 for the
        travel distances (supply cost) and equal to the total demand for the
        inequity measure. The last two objective weights can be adjusted using
        the property "omega", where omega is a tuple of two positive floats.
        
        See base class 'DFLProblem' in module dflprob.
        """
        super().__init__(fname=fname, formt=formt, unitCost=unitCost, scale=scale,\
                          d=d, s=s, f=f, c=c )
        
        self.set_default_options()
        
        self.__gratio = (np.sqrt(5)-1)/2.0
        """Golden section ratio"""
        
        self.__beta = 0.1 
        """Parameter beta in the conditional beta-mean"""
        
        self.__totD = 0.0 if self.d is None else self.d.sum()
        """Total demand"""
        
        self.__omega = (1,self.__totD)
        """Weights for the objectives "travel distance" and "inequity".
           The weight for the fixed cost is asssumed to be normed to 1."""
        
        self.__search_time = 600
        """Maximal time (sec) allowed for the solution search"""
        
        self.__unitCost = self.unitCost
        """Remember if suppy cost are per unit or total"""
        self.unitCost = False
        
        self.__C = self.c.copy()*self.d if self.__unitCost else self.c.copy()
        """Copy of the original supply cost matrix. Here we will
           see C(i,j) the cost to supply all of i's demand from j."""
           
        self.__U = None 
        """Numpy array of possible optimal u-values"""
        
        self.__umin = 0.0
        """Value of dual variable u where best solution found"""
        
        self.__mbeta = 0.0
        """Value of the conditional beta value in the solution found"""
        
        self.__objval = 0.0 
        """Actual objective value of the solution consisting of
        (i)  The fixed facility cost plus variable distribution cost
        (ii) The inequity cost/penalty."""
        
        self.__ubeta = 0.0
        """The actual u-value of the final solution. That is the (1-β)-
        quantile of the distance distribution of each demand unit."""
               
        self.__Dbeta = self.__totD*self.beta 
        """100beta% of the total demand"""
        
        self.F = None 
        """Dictionary of funtion values F(u)"""
        
        self.__fmin = 0.0
        """Objective value of solution to the CFLP with equity objective"""
         
    #---------------------------------------------
    # Class properties
    #---------------------------------------------
    @property 
    def beta(self):
        """
        Parameter beta in the conditional beta-mean.
        Inequity is measured as the average distance
        the 100*beta % demand units travelling 
        the longest distance have to travel.
        """
        return self.__beta
    
    @beta.setter 
    def beta(self, value : float ):
        """
        Set the beta value, a positive number strictly
        smaller than 1.
        """
        if value > 0 and value < 1: 
            self.__beta = value
            self.__Dbeta = value*self.__totD
    
    @property
    def omega(self):
        """
        Tuple of positive objective weights, where omega[0]
        is the travel distance weight and omega[1] the weight 
        for inequities in travel distances. Fixed cost have
        weight normed to 1.
        """
        return self.__omega

    @omega.setter
    def omega( self, value : tuple ): 
        self.__omegaa = value

    @property
    def search_time(self):
        """
        Maximal time in seconds to search for an optimal solution.
        """
        return self.__search_time

    @search_time.setter
    def search_time( self, value : float ): 
        self.__search_time = value
        
    @property 
    def screen_output(self):
        return self.__screen_output 
    
    @screen_output.setter
    def screen_output(self, value : bool):
        self.__screen_output = value     
        
    @property 
    def umin(self):
        """Value of dual variable u at which best solution was found"""
        return self.__umin
    
    @property
    def fmin(self):
        """Objective value of best solution found to the CFLP with equity objective"""
        return self.__fmin 
    
    @property 
    def beta_mean(self):
        """Return the conditional beta-mean for the obtained solution"""
        return self.__mbeta     
    
    @property 
    def inequity_cost(self):
        """Return the inequity cost (beta-mean times its weight)"""
        return self.omega[1]*self.__mbeta
    
    @property 
    def objval(self):
        """Return the final solution's objective value"""
        return self.__objval 
    
    @property
    def ubeta(self):
        """Return the value of dual variable in the final solution."""
        return self.__ubeta  
             
    #---------------------------------------------
    
    def set_default_options(self):
        """
        Set all options (back) to default values
        """
        self.default_options()
        self.solver = 'cplex'
        self.mipStrategy = 0
        self.nodeLim = 100
        self.__search_time = 600 
        self.__screen_output = True
        
    #---------------------------------------------
    
    def __comp_cond_beta(self, supply ):
        """
        Compute the conditional beta-mean for the
        given allocation 'supply' of demands.
        Return the cond. beta-mean value and the
        corresponding value of the dual variable u.
        Note that supply is a dictionary that
        for every (j,i) gives the value of
        x(j,i) if this is positive.
        """
        # Facility-customer index pairs with positive x(j,i)
        JI = sorted(supply.keys(), key = lambda ji : self.__C[ji]/self.d[ji[1]], reverse=True)
        # Solve the continuous knapsack problem
        dem_sum = 0.0
        capaci = self.__Dbeta 
        mbeta = 0.0
        for ji in JI: 
            _, i = ji 
            u, zji = self.__C[ji]/self.d[i], self.d[i]*supply[ji]
            if dem_sum + zji > capaci:
                zji = (capaci-dem_sum)
                mbeta += u*zji 
                dem_sum += zji 
                break  
            mbeta += u*zji 
            dem_sum += zji
        mbeta /= self.__Dbeta 
        u /= self.__Dbeta 
        return mbeta, u
     
    #---------------------------------------------
    
    def complete_solution( self, facilities, u=None ):
        """
        For given value u of the dual variable u, this procedure
        completes the solution by computing the demand allocation
        and the corresponding conditional β-mean. The resulting
        objective value, the obtained β-mean and the actual
        u-value corresponding to this β-mean are the stored
        in the attributes self.__objval, self.__mbeta and
        self.__ubeta. For computing the demand allocation,
        the corresponding transportation problem is solved
        using Cplex.
        """
        m = len(self.d)
        M = Model('FCFLP-alloc')

        x = M.continuous_var_dict( product(facilities,range(m)) )
        M.add_constraints_( M.sum( x[j,i] for j in facilities )== 1 for i in range(m) ) 
        M.add_constraints_( M.sum( self.d[i]*x[j,i] for i in range(m)) <= self.s[j] for j in facilities )
        
        # Cost coefficient of allocation variable x(j,i)
        if u is None:
            get_cost = lambda ji : self.c[ji]*self.d[ji[1]] if self.unitCost else self.c[ji]
        elif self.unitCost:
            # self.c(j,i) is the distance (cost per unit) on link j -> i
            unit_cost = lambda ji : self.__omega[0]*self.c[ji] + self.__omega[1] * \
                                   max( 0.0, self.c[ji]/self.__Dbeta - u )
            get_cost = lambda ji : self.d[ji[1]]*unit_cost(ji)
        else:
            get_cost = lambda ji : self.__omega[0]*self.c[ji] + self.__omega[1] * \
                                   max( 0.0, self.c[ji]/self.__Dbeta - u*self.d[ji[1]] )
        # Objective function
        M.minimize ( M.dotf( x, get_cost) )
        
        # Solve transportation problem and retrieve demand allocation
        s = M.solve( )
        self.supply = s.get_value_dict( x, keep_zeros=False )
        
        # Obtain objective value(s)
        tcost = sum( self.c[ji]*self.supply[ji]*self.d[ji[1]] for ji in self.supply.keys() ) if self.unitCost else \
                sum( self.c[ji]*self.supply[ji] for ji in self.supply.keys() )
        self.fcost = self.f[self.facilities].sum()
        self.cost = self.fcost + self.__omega[0]*tcost 
        self.__mbeta, self.__ubeta = self.__comp_cond_beta(self.supply)
        self.__objval = self.cost + self.__omega[1]*self.__mbeta 
        
        # Terminate docplex model   
        M.end()   
        
    #---------------------------------------------
    
    def __get_lb_on_u(self):
        """
        Compute a lower bound on the value of the dual
        variable u in an optimal solution. Obtain
        it as the dual solution to the linear program
        computing the conditional β-mean for the demand
        allocation when all facilities are open. Return
        the  largest index k in the sorted array self.__U such 
        that self.__U[k] is strictly smaller than this value.
        """
        n = len(self.f)
        self.complete_solution( range(n) )
        k = np.where( self.__U >= self.__ubeta-1.0E-05)[0][0]
        return max(0,k-1)
    
    #---------------------------------------------
    
    def __adjust_cost( self, u ):
        """
        Adjust the supply cost of the CFLP to account
        for the inequity measure. Parameter u is the
        current guess for the optimal dual variable u.
        """
        c_add = np.maximum( self.__C/(self.__Dbeta) - u*self.d,0.0)
        self.c = self.__C + self.__omega[1]*c_add if self.__omega[0]==1 else \
                 self.__omega[0]*self.__C + self.__omega[1]*c_add 
        M = self.model   
        if not M is None:
            # Overwrite coefficients of variables x(i,j) in objective function
            costij = lambda ji : self.c[ji[0],ji[1]]
            M.minimize( M.dotf( self.y, lambda j : self.f[j] ) + M.dotf( self.x, costij ) ) 
         
    #---------------------------------------------
    
    def __comp_F ( self, u, uvalue=False ):
        """
        Determine the value of the function 
        
            F(u) =  \min \sum_{ij} c_{ij}(u)*x_{ij} + \sum_j f_j y_j + \omega*\beta*D*u,
                
        where c_{ij}(u)= \omega[1]*c(i,j) + \omega*max{ 0, c(i,j)/(\beta*D) - u*d(i) }
        
        Parameters
        ----------
        u : float 
            u is the current guess for the optimal dual variable u.
            
        uvalue : bool 
            If True, the u-value corresponding to the obtained solution
            is also obtained. This is done by computing the corresponding
            value of the conditional beta-mean and returning the dual
            variable u, that is the distance the Dβ demand unit with
            largest distance has to travel.
        """
        new_u = 0.0
        self.__adjust_cost( u )
        if self.model is None: 
            self.solve( silent=True, keep_model=True, cpu_time=False)
            if uvalue and self._uncap and not self.assigned is None:
                self.supply = dict.fromkeys(map(lambda i : (self.assigned[i],i),range(len(self.d))), 1.0 )
            Fu = self.cost + self.__omega[1]*self.__Dbeta*u
        else:
            s = self.model.solve(log_output=False)
            self.cost = self.model.objective_value 
            Fu = self.cost + self.__omega[1]*self.__Dbeta*u
            if uvalue: self.supply = s.get_value_dict( self.x, keep_zeros=False )
            self.facilities = list( s.get_value_dict( self.y, keep_zeros=False, precision=0.1 ).keys())
            self.fcost = self.f[self.facilities].sum()
            self.tcost = self.cost - self.fcost 
        
        if uvalue:
            if self.supply is None: 
                # Problem not used using Cplex
                self.complete_solution(self.facilities, u)
                new_u = self.__ubeta 
            else:  
                _, new_u = self.__comp_cond_beta( self.supply )
                
        return Fu, new_u 
    
    #---------------------------------------------
    
    def get_full_func( self ):
        """
        Compute and return all function values F(u) for
        all possible optimal values of u. The result
        is stored in the dictionary self.F.
        """
        if self.__screen_output:
            print('='*32)
            print('Computing full function F(u)')
            print('-'*32)
            print('Iter',f"{'Current u':>11s}",f"{'F(u)':>14s}")
            print('-'*32)
            
        F = list()
        fmin = float('inf')
        if self.__U is None: np.unique( (self.c/self.d) / self.__Dbeta )   
        for itr, u in enumerate(self.__U):
            Fu, _ = self.__comp_F( u )
            F.append( Fu )
            if self.__screen_output: print(f"{itr:>4d}",f"{u:>11.7f}",f"{Fu:>14.2f}")
            if Fu < fmin: fmin, umin = Fu, u
        if self.__screen_output: 
            print('-'*32)
            print('Minimum at u=',umin,'Function value=',fmin)
            print('='*32)    
        
        self.c = self.__C/self.d if self.__unitCost else self.__C
        self.F = dict(zip(self.__U,F))
        self.unitCost = self.__unitCost
        
    #---------------------------------------------
    
    def draw_func(self):
        """
        Draw the function F(u). If the function is not
        yet computed, this is done first. 
        """
        if self.F is None: self.get_full_func()
        plt.plot(self.F.keys(), self.F.values()) 
        plt.xlabel('u') 
        plt.ylabel('F(u)') 
        plt.title('F(u)') 
        plt.show() 

    #---------------------------------------------
    
    def __gss(self, sharpen_interval = False ):
        """
        Golden section search for finding local minimum of F(u)
        """
        if self.__screen_output:
            print('='*60)
            print('Golden section search')
            print('-'*60)
            print(f"{'Iter':<4s}",f"{'Current u':>11s}",f"{'Objective(u)':>14s}",\
                  f"{'Best u':>11s}",f"{'Objective(u*)':>15s}")
            print('-'*60)
    
        uses_cpx = self.solver.lower()=='cplex'
        
        # The below only applies for the large Avella instances of size m=n=700 and m=n=500
        # For instances of size m=n=1000 use addVubs=0, mipStrategy=0 and
        # nodeLim=50 for instances of capacity-demand ration r=5,10 and
        # again the below for instances of ratio r=15, 20
        if uses_cpx: 
            self.mipStrategy = 0
            self.nodeLim = 50 
            self.useBenders = True
        itr, tottim = 0, 0.0
        
        F = dict()
        L, R, fmin = 0, len(self.__U), float('inf')
        
        # Get a sharper upper bound on optimal u-value
        if sharpen_interval: 
            if self.screen_output: print('Trying to sharpen lower and upper bound on u')
            itr += 1
            fmin, umin = self.__comp_F( self.__U[-1], uvalue=True )
            R = min(R, np.where( self.__U >=  umin )[0][0]+1)
            F[R] = fmin
            ybest = self.facilities.copy()
            L = self.__get_lb_on_u() # Need to come after comp. of R!!!
            if self.__screen_output:
                print('Found lower bound is:',self.__U[L])
                print('Found upper bound is:',umin) 
                print(f"{itr:>4d}",f"{umin:>11.7f}",f"{fmin:>14.2f}")
        u1, u2 = int( R - self.__gratio*(R-L) ), round(L + self.__gratio*(R-L))
        
        # Compute function values at u1 and u2
        f1, _ = self.__comp_F(self.__U[u1] )
        itr += 1
        tottim += self.model.solve_details.time if uses_cpx else self.ctime[1]
        if f1 < fmin: fmin, umin, ybest = f1, self.__U[u1], self.facilities.copy()
        if self.__screen_output:
            print(f"{itr:>4d}",f"{self.__U[u1]:>11.7f}",f"{f1:>14.2f}",f"{umin:>11.7f}",\
                  f"{fmin:>15.2f}")
        F[u1] = f1        
         
        f2, _ = self.__comp_F(self.__U[u2])
        itr += 1
        tottim += self.model.solve_details.time if uses_cpx else self.ctime[1]
        if f2 < fmin: fmin, umin, ybest = f2, self.__U[u2], self.facilities.copy()
        if self.__screen_output:
            print(f"{itr:>4d}",f"{self.__U[u2]:>11.7f}",f"{f2:>14.2f}",f"{umin:>11.7f}",\
                  f"{fmin:>15.2f}")
        F[u2] = f2
    
        while R-L > 1:
            if f1 > f2:
                L  = u1
                u1 = u2
                u2 = round( L + self.__gratio*(R-L) ) 
                f1 = f2
                u  = self.__U[u2]
                f2 = F.get(u2)
                if f2 is None:
                    itr += 1 
                    f2, _ = self.__comp_F(u)
                    F[u2] = f2
                fu = f2
            else:
                R  = u2
                u2 = u1
                u1 = int( R - self.__gratio*(R-L) )
                f2 = f1 
                u  = self.__U[u1]
                f1 = F.get(u1)
                if f1 is None:
                    itr += 1
                    f1, _ = self.__comp_F(self.__U[u1])
                    F[u1] = f1
                fu = f1 
            if fu < fmin: fmin, umin, ybest = fu, u, self.facilities.copy()
            if self.__screen_output:
                print(f"{itr:>4d}",f"{u:>11.7f}",f"{fu:>14.2f}",f"{umin:>11.7f}",\
                      f"{fmin:>15.2f}")
            tottim += self.model.solve_details.time if uses_cpx else self.ctime[1]
            if tottim > self.__search_time: break
        if self.__screen_output: print('-'*60)
        
        return umin, fmin, tottim, itr, ybest
    
    #---------------------------------------------
        
    def __ternary( self, sharpen_interval = True ):
        """
        Ternary search for finding local minimum of F(u)
        """
        if self.__screen_output:
            print('='*60)
            print('Ternary search')
            print('-'*60)
            print(f"{'Iter':<4s}",f"{'Current u':>11s}",f"{'Objective(u)':>14s}",\
                  f"{'Best u':>11s}",f"{'Objective(u*)':>15s}")
            print('-'*60)
    
        uses_cpx = self.solver.lower()=='cplex'
        itr, tottim = 0, 0.0
        
        F = dict()
    
        l, r = 0, len(self.__U)-1
        fmin, umin = float('inf'), None
        
        if sharpen_interval: 
            if self.screen_output: print('Trying to sharpen lower and upper bound on u')
            L = self.__get_lb_on_u()
            itr += 1
            fmin, umin = self.__comp_F( self.__U[-1], uvalue=True )
            r = min(r, np.where( self.__U >=  umin )[0][0]+1)
            F[r] = fmin
            ybest = self.facilities.copy()
            if self.__screen_output:
                print('Found lower bound is:',self.__U[L])
                print('Found upper bound is:',umin) 
                print(f"{itr:>4d}",f"{umin:>11.7f}",f"{fmin:>14.2f}")
        
        while r-l > 2:
            mid1 = int( l + (r - l) / 3.0 )
            mid2 = int( r - (r - l) / 3.0 )
            u1, u2 = self.__U[mid1], self.__U[mid2]
            f_mid1 = F.get(mid1)
            if f_mid1 is None:
                itr += 1
                f_mid1, _ = self.__comp_F( u1 )
                F[mid1] = f_mid1
                if f_mid1 < fmin: fmin, umin, ybest = f_mid1, u1, self.facilities.copy()
                tottim += self.model.solve_details.time if uses_cpx else self.ctime[1]
            if self.__screen_output:
                print(f"{itr:>4d}",f"{u1:>11.7f}",f"{f_mid1:>14.2f}",f"{umin:>11.7f}",\
                      f"{fmin:>15.2f}")
            f_mid2 = F.get(mid2)
            if f_mid2 is None:
                itr += 1 
                f_mid2, _ = self.__comp_F( u2 )
                F[mid2] = f_mid2
                if f_mid2 < fmin: fmin, umin, ybest = f_mid2, u2, self.facilities.copy()
                tottim += self.model.solve_details.time if uses_cpx else self.ctime[1]
            if self.__screen_output:
                print(f"{itr:>4d}",f"{u2:>11.7f}",f"{f_mid2:>14.2f}",f"{umin:>11.7f}",\
                      f"{fmin:>15.2f}")
            if f_mid1 < f_mid2:
                r = mid2
            elif f_mid1 > f_mid2:
                l = mid1
            else:
                l = mid1
                r = mid2
            if tottim > self.__search_time: break
        
        if self.__screen_output: print('-'*60)
        
        return umin, fmin, tottim, itr, ybest 
    
    #---------------------------------------------
    
    def fair_solver(self, search_method = 'gss', sharpen_interval = False ):
        """
        Solve the CFLP with equity objective as a parametric CFLP depending on a 
        single parameter u.
        """
        # Obtain list of possible u-values
        if self.__U is None: self.__U = np.unique( (self.c/self.d) / self.__Dbeta )
        
        # Solve the problem using golden section search
        self.__umin, self.__fmin, tottim, itr, ybest = \
            self.__gss(sharpen_interval=sharpen_interval) if search_method.lower()=='gss' else \
            self.__ternary( sharpen_interval=sharpen_interval )
        
        # Restore solution found by solving the model with capacities
        # of closed facilities set to zero and all fixed cost set to
        # zero
        self.c = self.__C/self.d if self.__unitCost else self.__C
        self.unitCost = self.__unitCost
        if not self.model is None:
            self.model.end()
            self.model = None
        self.itr = itr
        self.ctime = (tottim,tottim)
        self.facilities = ybest 
        self.complete_solution( ybest, self.__umin )  
